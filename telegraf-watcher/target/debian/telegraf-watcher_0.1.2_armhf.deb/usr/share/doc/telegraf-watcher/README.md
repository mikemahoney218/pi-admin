# Telegraf Watcher

Small service to restart telegraf on modification of config file.
